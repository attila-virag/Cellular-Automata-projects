import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Convay_s_game_of_life extends PApplet {

final int X = 200;
final int Y = 140;
final int boxSize = 8;

final int onBoxColor = color(255);
final int offBoxColor = color(50);
//final color dyingBoxColor = color(0,0,255);

boolean paused = false;

int [][] boxes = new int [X][Y];
int [][] boxesColor = new int [X][Y];
int [][] nextColors = new int [X][Y];

public void MakeB_Heptaplet(int x, int y) {
  boxesColor[x][y+2] = onBoxColor;
  
  boxesColor[x+1][y] = onBoxColor;
  boxesColor[x+1][y+1] = onBoxColor;
  
  boxesColor[x+2][y] = onBoxColor;
  
  boxesColor[x+3][y] = onBoxColor;
  
  boxesColor[x+4][y+1] = onBoxColor;
}

public void MakeLightSpaceship(int x, int y) {
  boxesColor[x][y+1] = onBoxColor;
  
  boxesColor[x+1][y] = onBoxColor;
  
  boxesColor[x+2][y] = onBoxColor;
  boxesColor[x+2][y+4] = onBoxColor;
  
  boxesColor[x+3][y] = onBoxColor;
  boxesColor[x+3][y+1] = onBoxColor;
  boxesColor[x+3][y+2] = onBoxColor;
  boxesColor[x+3][y+3] = onBoxColor;
}

public void MakePuffer2(int x, int y) {
  MakeLightSpaceship(x, y);
  MakeLightSpaceship(x+14, y);
  
  MakeB_Heptaplet(x+7, y+2);
}

public void MakeMissle(int x, int y) {
  boxesColor[x][y] = onBoxColor;
  boxesColor[x][y+1] = onBoxColor;
  
  boxesColor[x+1][y] = onBoxColor; 
  boxesColor[x+1][y+2] = onBoxColor;
  
  boxesColor[x+2][y] = onBoxColor;
}

public void MakeSpaceship(int x, int y) {
  boxesColor[x][y+2] = onBoxColor;
  boxesColor[x][y+3] = onBoxColor;
  
  boxesColor[x+1][y+1] = onBoxColor;
  boxesColor[x+1][y+3] = onBoxColor;
  
  boxesColor[x+2][y] = onBoxColor;
  boxesColor[x+2][y+1] = onBoxColor;
  boxesColor[x+2][y+2] = onBoxColor;
  boxesColor[x+2][y+5] = onBoxColor;
  boxesColor[x+2][y+8] = onBoxColor;
  
  boxesColor[x+3][y] = onBoxColor;
  boxesColor[x+3][y+1] = onBoxColor;
  boxesColor[x+3][y+2] = onBoxColor;
  boxesColor[x+3][y+5] = onBoxColor;
  boxesColor[x+3][y+9] = onBoxColor;
  
  boxesColor[x+4][y] = onBoxColor;
  boxesColor[x+4][y+1] = onBoxColor;
  boxesColor[x+4][y+2] = onBoxColor;
  boxesColor[x+4][y+9] = onBoxColor;
  
  boxesColor[x+5][y] = onBoxColor;
  boxesColor[x+5][y+1] = onBoxColor;
  boxesColor[x+5][y+3] = onBoxColor;
  boxesColor[x+5][y+6] = onBoxColor;
  boxesColor[x+5][y+9] = onBoxColor;
  
  boxesColor[x+6][y+1] = onBoxColor;
  boxesColor[x+6][y+2] = onBoxColor;
  boxesColor[x+6][y+3] = onBoxColor;
  boxesColor[x+6][y+7] = onBoxColor;
  boxesColor[x+6][y+8] = onBoxColor;
  boxesColor[x+6][y+9] = onBoxColor;
  
  boxesColor[x+7][y+2] = onBoxColor;
}

public void MakeGliderGun(int x, int y) {
  boxesColor[x][y+5] = onBoxColor;
  boxesColor[x][y+6] = onBoxColor;
  boxesColor[x+1][y+5] = onBoxColor;
  boxesColor[x+1][y+6] = onBoxColor;
  
  boxesColor[x+10][y+5] = onBoxColor;
  boxesColor[x+10][y+6] = onBoxColor;
  boxesColor[x+10][y+7] = onBoxColor;
  
  boxesColor[x+11][y+4] = onBoxColor;
  boxesColor[x+11][y+8] = onBoxColor;
  
  boxesColor[x+12][y+3] = onBoxColor;
  boxesColor[x+12][y+9] = onBoxColor;
  
  boxesColor[x+13][y+3] = onBoxColor;
  boxesColor[x+13][y+9] = onBoxColor;
  
  boxesColor[x+14][y+6] = onBoxColor;
  
  boxesColor[x+15][y+4] = onBoxColor;
  boxesColor[x+15][y+8] = onBoxColor;
  
  boxesColor[x+16][y+5] = onBoxColor;
  boxesColor[x+16][y+6] = onBoxColor;
  boxesColor[x+16][y+7] = onBoxColor;
  
  boxesColor[x+17][y+6] = onBoxColor;
  
  boxesColor[x+20][y+3] = onBoxColor;
  boxesColor[x+20][y+4] = onBoxColor;
  boxesColor[x+20][y+5] = onBoxColor;
  
  boxesColor[x+21][y+3] = onBoxColor;
  boxesColor[x+21][y+4] = onBoxColor;
  boxesColor[x+21][y+5] = onBoxColor;
  
  boxesColor[x+22][y+2] = onBoxColor;
  boxesColor[x+22][y+6] = onBoxColor;

  boxesColor[x+24][y+1] = onBoxColor;
  boxesColor[x+24][y+2] = onBoxColor;
  boxesColor[x+24][y+6] = onBoxColor;
  boxesColor[x+24][y+7] = onBoxColor;
  
  boxesColor[x+34][y+3] = onBoxColor;
  boxesColor[x+34][y+4] = onBoxColor;
  boxesColor[x+35][y+3] = onBoxColor;
  boxesColor[x+35][y+4] = onBoxColor;
}

public void settings() {
  //this should be here
  size(X * boxSize, Y * boxSize);
}

public void setup() {
  for (int i = 0; i< boxes.length; i++) {
    for (int j = 0; j < boxes[i].length; j++) {
      boxes[i][j] = j;
      boxesColor[i][j] = offBoxColor;
      nextColors[i][j] = offBoxColor;
    }
  }
  //MakeGliderGun(10,10);
  //MakeGliderGun(10,50);
}



public void UpdateBoxState(int i, int j) {

  int currentBoxColor = boxesColor[i][j];

  int neighborBoxesOn = 0;
  //int neighborBoxesOff = 0;

  int x_pos, y_pos;
  // check the surrounding 9 boxes, wrap around if needed
  for (int x = i-1; x <= i+1; x++) {
    // check for wrap around
    if (x < 0) {
      x_pos = X-1;
    } else if (x > X-1) {
      x_pos = 0;
    } else {
      x_pos = x;
    }
    for (int y = j-1; y <= j+1; y++) {
      // check for wrap around
      if (y < 0) {
        y_pos = Y-1;
      } else if (y > Y-1) {
        y_pos = 0;
      } else {
        y_pos = y;
      }

      if (x_pos == i && y_pos == j ) {
        continue;
      }

      // now we can check the state of box at x_pos,y_pos
      int current = boxesColor[x_pos][y_pos];

      if (current == onBoxColor) {
        neighborBoxesOn++;
      } else if (current == offBoxColor) {
        //neighborBoxesOff++;
      }
    }
  }

  if (currentBoxColor == onBoxColor) {
    // if it has 2 or three neighbors it stays on else goes off
    if (neighborBoxesOn > 1 && neighborBoxesOn < 4) {
      nextColors[i][j] = onBoxColor;
      return;
    }
    // else goes off
    nextColors[i][j] = offBoxColor;
    return;
  } else if (currentBoxColor == offBoxColor) {
    // it goes on if it has exactly 3 live neighbors
    if (neighborBoxesOn == 3) {
      nextColors[i][j] = onBoxColor;
      return;
    } else {
      nextColors[i][j] = offBoxColor;
    }
  }
}

public void UpdateBoxes() {
  for (int i = 0; i< boxes.length; i++) {
    for (int j = 0; j < boxes[i].length; j++) {

      UpdateBoxState(i, j);
    }
  }
}

public void draw() {
  for (int i = 0; i< boxes.length; i++) {
    for (int j = 0; j < boxes[i].length; j++) {
      int x = i * boxSize;
      int y = j * boxSize;

      fill(boxesColor[i][j]);
      stroke(0);
      rect (x, y, boxSize, boxSize);
    }
  }

  if (!paused) {
    UpdateBoxes();
    for (int i = 0; i< boxes.length; i++) {
      for (int j = 0; j < boxes[i].length; j++) {
        boxesColor[i][j] = nextColors[i][j];
      }
    }
  }
}

public void mousePressed() {
  if (mouseButton == LEFT) {
    boxesColor[mouseX / boxSize][mouseY / boxSize] = onBoxColor;
    //color current = boxesColor[mouseX / boxSize][mouseY / boxSize];
    //if(current == onBoxColor) {
    //  boxesColor[mouseX / boxSize][mouseY / boxSize] = offBoxColor;
    //}
    //else if (current == offBoxColor) {
    //  boxesColor[mouseX / boxSize][mouseY / boxSize] = onBoxColor;
    //}
  } else if (mouseButton == RIGHT) {
    paused = !paused;
  }
}

public void mouseDragged() {
  if (mouseButton == LEFT) {
    if(mouseX > 0 && mouseX < X*boxSize && mouseY > 0 && mouseY < Y*boxSize) {
    boxesColor[mouseX / boxSize][mouseY / boxSize] = onBoxColor;
    }
  }
}


public void keyPressed() {
  if (key == BACKSPACE) {
    // restart

    for (int i = 0; i< boxes.length; i++) {
      for (int j = 0; j < boxes[i].length; j++) {
        boxes[i][j] = j;
        boxesColor[i][j] = offBoxColor;
      }
    }
  }
  if (key == ENTER) {
    if(mouseX > 0 && mouseX < X*boxSize-40 && mouseY > 0 && mouseY < Y*boxSize-40) {
      MakeGliderGun(mouseX / boxSize,mouseY / boxSize);
    }
  }
  if(key == 'a' || key == 'A') {
    MakeB_Heptaplet(mouseX / boxSize,mouseY / boxSize);
  }
  if(key == 's' || key == 'S') {
    MakeLightSpaceship(mouseX / boxSize,mouseY / boxSize);
  }
  if(key == 'p' || key == 'P') {
   MakePuffer2( mouseX / boxSize,mouseY / boxSize);
  }
  if(key == 'm' || key == 'M') {
   MakeMissle(mouseX / boxSize,mouseY / boxSize); 
  }
  if(key == 'w' || key == 'W') {
   MakeSpaceship(mouseX / boxSize,mouseY / boxSize); 
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Convay_s_game_of_life" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
